package com.capgemini.lesson4;

import com.capgemini.lesson4.demo.Balance;

class AccountBalance {
	public static void main(String args[]) {

		Balance current = new Balance("K. J. Fielding", 123.23);
		current.show();

	}
}
